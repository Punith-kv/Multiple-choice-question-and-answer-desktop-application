package com.QuizApp.MCQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McqApplication {

	public static void main(String[] args) {
		SpringApplication.run(McqApplication.class, args);
	}

}
